static const char driver_sha[] = "25a7423071ea7b2b6fb677b6ad18cbc7bbb87989719228a4654f9c0a5aa9750d";
static int hash_file(const wchar_t *path, char out[65]) {
    HANDLE f = CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if (f==INVALID_HANDLE_VALUE) return 0;
    BCRYPT_ALG_HANDLE alg=NULL; BCRYPT_HASH_HANDLE hash=NULL;
    PUCHAR object=NULL; ULONG size=0,done=0; BYTE digest[32],buf[16384];
    int ok=0;
    if (BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0) goto cleanup;
    if (BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,(PUCHAR)&size,sizeof(size),&done,0)<0 || !size) goto cleanup;
    object=HeapAlloc(GetProcessHeap(),0,size); if (!object) goto cleanup;
    if (BCryptCreateHash(alg,&hash,object,size,NULL,0,0)<0) goto cleanup;
    for (;;) {
        DWORD got=0;
        if (!ReadFile(f,buf,sizeof(buf),&got,NULL)) goto cleanup;
        if (!got) break;
        if (BCryptHashData(hash,buf,got,0)<0) goto cleanup;
    }
    if (BCryptFinishHash(hash,digest,sizeof(digest),0)<0) goto cleanup;
    for (unsigned i=0;i<32;i++) { out[2*i]="0123456789abcdef"[digest[i]>>4]; out[2*i+1]="0123456789abcdef"[digest[i]&15]; }
    out[64]=0;ok=1;
cleanup:
    if (hash) BCryptDestroyHash(hash);
    if (object) HeapFree(GetProcessHeap(),0,object);
    if (alg) BCryptCloseAlgorithmProvider(alg,0);
    CloseHandle(f);return ok;
}
