# T1 Backlight Control

A tiny portable Windows x64 utility for manually controlling the built-in SPI
keyboard backlight on a MacBook Pro A1706 with a non-working T1 chip.

Five buttons: **25%, 50%, 75%, 100%, Off**. No installation, application log
files, startup tasks, or background polling. The app uses the existing Apple SPI
keyboard driver. It does not perform T1 recovery or firmware operations.

## Use

Run `T1-Backlight-Control.exe` and click a brightness button. Launching or closing
the app does not change brightness. Close an older instance before starting an
updated executable. Keep the EXE; the download command is needed only once.

## Compatibility

The SPI control path was physically tested by the user on an A1706 with T1 in
DFU. This is deliberately restricted to the reviewed `AppleSPIKeyboard.sys`
version 6.1.7700.0, SHA-256:

```
25a7423071ea7b2b6fb677b6ad18cbc7bbb87989719228a4654f9c0a5aa9750d
```

The driver must advertise backlight support with a raw range of 32–512.
Other Mac models and driver versions have not been validated. Apple drivers
are required to be installed already and are **not distributed** in this project.
Boot Camp can subsequently change brightness through its own automatic controls.

## Version 0.2.1

The user confirmed that brightness changes correctly despite intermittent
Windows error 31 (`ERROR_GEN_FAILURE`) returned by the brightness command.
Version 0.2.1 does not display a popup for that specific setter result and does
not repeat the write. This is an **unconfirmed completion**, not brightness
readback or a general fix to the Apple driver. Error 31 during capability reads,
other errors, and timeouts remain visible. A timeout disables further writes
until the app is restarted. There are no application log files.

## Build

Use a MinGW-w64 x64 toolchain with GCC, windres, and strip:

```sh
bash build.sh
```

Only Windows system libraries are linked; no separate runtime packages are
needed by the compiled executable. The toolchain is needed only for building.
The build script writes the EXE beside the source files.

## Tests

```sh
./T1-Backlight-Control.exe --self-test
```

This checks packet generation and range rejection without device access.
`--check-only` checks the installed driver and cached capabilities without a
window or a brightness write. Both return an exit code and write no report.

`test_errors.c` is a test harness that includes the actual application code and
mocks the Windows device APIs; it never sends brightness commands to hardware.
It covers 19 cases: all five levels, immediate and asynchronous error 31,
capability-query failure, access denied, disconnection, and timeout. It reads
and hashes the installed driver, so that reviewed file is still required.
Example cross-compile command:

```sh
x86_64-w64-mingw32-gcc -O2 -Wall -Wextra -Werror -D_WIN32_WINNT=0x0601 \
  test_errors.c \
  -Wl,--wrap=__imp_CreateFileW,--wrap=__imp_DeviceIoControl,--wrap=__imp_GetOverlappedResult,--wrap=__imp_WaitForSingleObject,--wrap=__imp_CancelIoEx \
  -lbcrypt -lshell32 -lgdi32 -luser32 -o test-errors.exe
```

The application and mocked tests were run under Wine. Physical backlight
control and the intermittent completion issue were reported on the user's
Windows installation; the new error handling still needs native confirmation.

## Protocol

Device: `\\.\AppleSPIKeyboard`.

- Cached capability query: `0xB403204C`, zero input bytes, seven output bytes.
- Brightness setter: `0xB4032050`, five input bytes, no output buffer.
- Input: `[01, level_lo, level_hi, F4, 01]`, using the same 500 ms fade as Boot Camp.
- Raw levels: off=0, 25%=152, 50%=272, 75%=392, 100%=512.

Percentages refer to the command scale, not measured light output. The app
verifies the driver SHA-256 and capability range before each command. It does
not modify drivers, services, partitions, EFI, or persistent settings.

## License

MIT. See [LICENSE](LICENSE). Apple binaries are not included.
