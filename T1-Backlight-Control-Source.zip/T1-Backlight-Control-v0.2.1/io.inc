struct io_state { OVERLAPPED ov; BYTE input[5],output[7]; };
static int io_request(HANDLE device, int setting, const BYTE packet[5], BYTE output[7], DWORD *returned, DWORD *error) {
    struct io_state *s=HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(*s));
    if(!s){*error=ERROR_NOT_ENOUGH_MEMORY;return 0;}
    s->ov.hEvent=CreateEventW(NULL,TRUE,FALSE,NULL);
    if(!s->ov.hEvent){*error=GetLastError();HeapFree(GetProcessHeap(),0,s);return 0;}
    if(setting)memcpy(s->input,packet,5);
    BOOL ok=DeviceIoControl(device,setting?SPI_BACKLIGHT_SET:SPI_BACKLIGHT_QUERY,
        setting?s->input:NULL,setting?5:0,setting?NULL:s->output,setting?0:7,returned,&s->ov);
    if(!ok){
        *error=GetLastError();
        if(*error!=ERROR_IO_PENDING)goto failure;
        DWORD wait=WaitForSingleObject(s->ov.hEvent,5000);
        if(wait!=WAIT_OBJECT_0){
            DWORD cause=wait==WAIT_TIMEOUT?ERROR_TIMEOUT:GetLastError();
            CancelIoEx(device,&s->ov);
            /* Never repeat a timed-out write: hardware may already have received it. */
            uncertain=1;
            WaitForSingleObject(s->ov.hEvent,1000);
            DWORD ignored;
            if(!GetOverlappedResult(device,&s->ov,&ignored,FALSE) && GetLastError()==ERROR_IO_INCOMPLETE){
                *error=cause;return 0; /* retain buffers until process exits */
            }
            *error=cause;goto failure;
        }
    }
    if(!GetOverlappedResult(device,&s->ov,returned,FALSE)){*error=GetLastError();goto failure;}
    if(!setting)memcpy(output,s->output,7);
    *error=0;CloseHandle(s->ov.hEvent);HeapFree(GetProcessHeap(),0,s);return 1;
failure:
    CloseHandle(s->ov.hEvent);HeapFree(GetProcessHeap(),0,s);return 0;
}
