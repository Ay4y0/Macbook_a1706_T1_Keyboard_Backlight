/* Five-button control. No application log files, persistence or automatic writes. */
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <shellapi.h>
#include <stdint.h>
#include <wchar.h>
#include "backlight_protocol.h"
#include "driver_hash.inc"
#define DONE_MESSAGE (WM_APP+1)
static HWND main_window,buttons[5];
static HFONT font;
static int busy,ready,uncertain;
static const int levels[5]={25,50,75,100,0};
static wchar_t error_text[256];
#include "io.inc"

static void failure(const wchar_t *text,DWORD error) {
    if(error)swprintf(error_text,256,L"%ls\nКод Windows: %lu.",text,error);
    else {wcsncpy(error_text,text,255);error_text[255]=0;}
}
static void perform_action(int percent) {
    error_text[0]=0;ready=0;
    wchar_t path[MAX_PATH];UINT n=GetSystemDirectoryW(path,MAX_PATH);
    const wchar_t suffix[]=L"\\drivers\\AppleSPIKeyboard.sys";
    if(!n || n+wcslen(suffix)>=MAX_PATH){failure(L"Не удалось найти драйвер клавиатуры.",0);return;}
    wcscat(path,suffix);char digest[65];
    if(!hash_file(path,digest)){failure(L"Не удалось прочитать драйвер клавиатуры.",0);return;}
    if(strcmp(digest,driver_sha)){failure(L"Эта версия драйвера клавиатуры не поддерживается.",0);return;}
    HANDLE device=CreateFileW(L"\\\\.\\AppleSPIKeyboard",GENERIC_READ|(percent<0?0:GENERIC_WRITE),
        FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_FLAG_OVERLAPPED,NULL);
    if(device==INVALID_HANDLE_VALUE){failure(L"Не удалось открыть SPI-клавиатуру.",GetLastError());return;}
    BYTE cap[7]={0},packet[5];DWORD count=0,error=0;
    if(!io_request(device,0,NULL,cap,&count,&error)){
        failure(L"Не удалось проверить поддержку подсветки.",error);goto finish;
    }
    if(!make_backlight_packet(cap,count,percent<0?25:percent,packet)){
        failure(L"Подсветка или диапазон яркости не поддерживается.",0);goto finish;
    }
    ready=1;
    if(percent>=0){
        count=0;
        /* Hardware-tested requests can finish with ERROR_GEN_FAILURE even when
         * the light changes. Leave this completion unconfirmed and silent;
         * never retry it. Other errors, including query failures, stay visible. */
        if(!io_request(device,1,packet,NULL,&count,&error) && error!=ERROR_GEN_FAILURE)
            failure(L"Не удалось изменить яркость подсветки.",error);
    }
finish:
    CloseHandle(device);
    if(uncertain){ready=0;failure(L"Запрос не завершился вовремя. Закрой и снова открой приложение.",0);}
}
static DWORD WINAPI worker(LPVOID param) {
    int percent=(int)(INT_PTR)param;
    perform_action(percent);
    PostMessageW(main_window,DONE_MESSAGE,(WPARAM)(INT_PTR)percent,0);return 0;
}
static void start_action(int percent) {
    if(busy)return;
    busy=1;
    for(int i=0;i<5;i++)EnableWindow(buttons[i],FALSE);
    HANDLE thread=CreateThread(NULL,0,worker,(LPVOID)(INT_PTR)percent,0,NULL);
    if(thread)CloseHandle(thread);
    else {
        busy=0;
        for(int i=0;i<5;i++)EnableWindow(buttons[i],ready && !uncertain);
        MessageBoxW(main_window,L"Не удалось запустить запрос.",L"Подсветка",MB_OK|MB_ICONWARNING);
    }
}
static LRESULT CALLBACK window_proc(HWND w,UINT message,WPARAM wp,LPARAM lp) {
    switch(message){
    case WM_CREATE:{
        main_window=w;
        font=CreateFontW(-16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        const wchar_t *labels[5]={L"25%",L"50%",L"75%",L"100%",L"Выкл"};
        for(int i=0;i<5;i++){
            buttons[i]=CreateWindowExW(0,L"BUTTON",labels[i],WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,
                12+i*88,12,80,36,w,(HMENU)(INT_PTR)(101+i),GetModuleHandleW(NULL),NULL);
            SendMessageW(buttons[i],WM_SETFONT,(WPARAM)font,TRUE);
        }
        start_action(-1);return 0;
    }
    case WM_COMMAND:
        if(HIWORD(wp)==BN_CLICKED && LOWORD(wp)>=101 && LOWORD(wp)<=105){
            if(ready)start_action(levels[LOWORD(wp)-101]);
            return 0;
        }break;
    case DONE_MESSAGE:
        busy=0;
        for(int i=0;i<5;i++){
            EnableWindow(buttons[i],ready && !uncertain);
            if(!error_text[0] && (int)(INT_PTR)wp>=0)
                SendMessageW(buttons[i],BM_SETSTYLE,levels[i]==(int)(INT_PTR)wp?BS_DEFPUSHBUTTON:BS_PUSHBUTTON,TRUE);
        }
        if(error_text[0])MessageBoxW(w,error_text,L"Подсветка",MB_OK|MB_ICONWARNING);
        return 0;
    case WM_CLOSE:
        if(busy){MessageBeep(MB_OK);return 0;}
        DestroyWindow(w);return 0;
    case WM_DESTROY:if(font)DeleteObject(font);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(w,message,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,PWSTR command,int show) {
    (void)previous;(void)command;
    int argc=0;LPWSTR *argv=CommandLineToArgvW(GetCommandLineW(),&argc);
    if(!argv)return 2;
    if(argc==2 && !wcscmp(argv[1],L"--self-test")){LocalFree(argv);return protocol_self_test()?0:10;}
    if(argc==2 && !wcscmp(argv[1],L"--check-only")){LocalFree(argv);perform_action(-1);return ready?0:1;}
    if(argc!=1){LocalFree(argv);return 2;}
    LocalFree(argv);
    HANDLE mutex=CreateMutexW(NULL,FALSE,L"Local\\T1BacklightControl_0_1");
    if(!mutex || GetLastError()==ERROR_ALREADY_EXISTS){if(mutex)CloseHandle(mutex);return 3;}
    WNDCLASSW cls={0};cls.lpfnWndProc=window_proc;cls.hInstance=instance;cls.lpszClassName=L"T1BacklightControl";
    cls.hCursor=LoadCursorW(NULL,IDC_ARROW);cls.hIcon=LoadIconW(NULL,IDI_APPLICATION);cls.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);
    if(!RegisterClassW(&cls)){CloseHandle(mutex);return 4;}
    DWORD style=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;RECT size={0,0,456,60};AdjustWindowRect(&size,style,FALSE);
    HWND w=CreateWindowExW(0,cls.lpszClassName,L"Подсветка клавиатуры",style,
        CW_USEDEFAULT,CW_USEDEFAULT,size.right-size.left,size.bottom-size.top,NULL,NULL,instance,NULL);
    if(!w){CloseHandle(mutex);return 5;}
    ShowWindow(w,show);UpdateWindow(w);
    MSG msg;int rc;
    while((rc=GetMessageW(&msg,NULL,0,0))>0){if(!IsDialogMessageW(w,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}
    CloseHandle(mutex);return rc<0?6:(int)msg.wParam;
}
