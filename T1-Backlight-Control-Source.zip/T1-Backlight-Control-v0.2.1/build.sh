#!/bin/sh
set -eu
cd "$(dirname "$0")"
x86_64-w64-mingw32-windres control.rc control-resource.o
x86_64-w64-mingw32-gcc -O2 -Wall -Wextra -Werror -D_WIN32_WINNT=0x0601 -municode -mwindows -static -static-libgcc control.c control-resource.o -lbcrypt -lshell32 -o T1-Backlight-Control.exe
x86_64-w64-mingw32-strip T1-Backlight-Control.exe
