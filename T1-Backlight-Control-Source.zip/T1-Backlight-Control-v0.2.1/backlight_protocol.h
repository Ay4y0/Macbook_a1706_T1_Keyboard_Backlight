#ifndef BACKLIGHT_PROTOCOL_H
#define BACKLIGHT_PROTOCOL_H
#include <stdint.h>
#include <stddef.h>
#define SPI_BACKLIGHT_QUERY 0xb403204cUL
#define SPI_BACKLIGHT_SET 0xb4032050UL
/* Restricted to the reviewed driver and the live capability report from this Mac. */
static int make_backlight_packet(const uint8_t *cap, size_t n, int percent, uint8_t packet[5]) {
    if (!cap || !packet || n != 7 || cap[0] != 1) return 0;
    unsigned lo=(unsigned)cap[3] | ((unsigned)cap[4]<<8);
    unsigned hi=(unsigned)cap[5] | ((unsigned)cap[6]<<8);
    if (lo != 32 || hi != 512) return 0;
    if (percent != 0 && percent != 25 && percent != 50 && percent != 75 && percent != 100) return 0;
    unsigned raw=percent ? lo+(hi-lo)*(unsigned)percent/100 : 0;
    packet[0]=1;packet[1]=(uint8_t)raw;packet[2]=(uint8_t)(raw>>8);
    /* Same 500 ms fade used by the supplied Bootcamp.exe. */
    packet[3]=0xf4;packet[4]=1;
    return 1;
}
static int protocol_self_test(void) {
    uint8_t cap[7]={1,0,0,32,0,0,2},p[5];
    if(!make_backlight_packet(cap,7,25,p) || p[0]!=1 || p[1]!=152 || p[2]!=0 || p[3]!=0xf4 || p[4]!=1) return 0;
    if(!make_backlight_packet(cap,7,50,p) || p[1]!=16 || p[2]!=1) return 0;
    if(!make_backlight_packet(cap,7,75,p) || p[1]!=136 || p[2]!=1) return 0;
    if(!make_backlight_packet(cap,7,100,p) || p[1]!=0 || p[2]!=2) return 0;
    if(!make_backlight_packet(cap,7,0,p) || p[1]!=0 || p[2]!=0) return 0;
    if(make_backlight_packet(cap,6,25,p) || make_backlight_packet(cap,8,25,p) || make_backlight_packet(cap,7,101,p) || make_backlight_packet(cap,7,-1,p) || make_backlight_packet(cap,7,1,p)) return 0;
    cap[0]=0;if(make_backlight_packet(cap,7,25,p)) return 0;
    cap[0]=1;cap[3]=31;if(make_backlight_packet(cap,7,25,p)) return 0;
    cap[3]=32;cap[6]=3;if(make_backlight_packet(cap,7,25,p)) return 0;
    return 1;
}
#endif
