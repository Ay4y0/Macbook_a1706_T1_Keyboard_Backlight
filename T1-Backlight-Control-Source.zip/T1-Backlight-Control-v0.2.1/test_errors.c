#define wWinMain control_application_entry
#include "control.c"
#undef wWinMain
#include <stdio.h>
static DWORD query_error,set_error;
static int query_calls,set_calls,pending,cancelled;
static DWORD last_request;

HANDLE WINAPI __wrap_CreateFileW(LPCWSTR path,DWORD access,DWORD share,LPSECURITY_ATTRIBUTES sa,DWORD creation,DWORD flags,HANDLE template_file){
 if(!wcscmp(path,L"\\\\.\\AppleSPIKeyboard"))return CreateEventW(NULL,TRUE,FALSE,NULL);
 typedef HANDLE (WINAPI *open_fn)(LPCWSTR,DWORD,DWORD,LPSECURITY_ATTRIBUTES,DWORD,DWORD,HANDLE);
 open_fn real_open=(open_fn)(void*)GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"CreateFileW");
 return real_open(path,access,share,sa,creation,flags,template_file);
}
BOOL WINAPI __wrap_DeviceIoControl(HANDLE h,DWORD code,LPVOID input,DWORD in_size,LPVOID output,DWORD out_size,LPDWORD bytes,LPOVERLAPPED ov){
 (void)h;(void)input;(void)in_size;last_request=code;*bytes=0;
 if(code==SPI_BACKLIGHT_QUERY){
  query_calls++;
  if(query_error){SetLastError(query_error);return FALSE;}
  const BYTE cap[7]={1,0,0,32,0,0,2};if(out_size!=7)return FALSE;
  memcpy(output,cap,7);*bytes=7;return TRUE;
 }
 if(code==SPI_BACKLIGHT_SET){
  set_calls++;
  if(pending){if(set_error!=ERROR_TIMEOUT)SetEvent(ov->hEvent);SetLastError(ERROR_IO_PENDING);return FALSE;}
  if(set_error){SetLastError(set_error);return FALSE;}
  return TRUE;
 }
 SetLastError(ERROR_INVALID_FUNCTION);return FALSE;
}
BOOL WINAPI __wrap_GetOverlappedResult(HANDLE h,LPOVERLAPPED ov,LPDWORD bytes,BOOL wait){
 (void)h;(void)ov;(void)wait;
 if(last_request==SPI_BACKLIGHT_SET && set_error){SetLastError(set_error==ERROR_TIMEOUT?ERROR_OPERATION_ABORTED:set_error);return FALSE;}
 *bytes=last_request==SPI_BACKLIGHT_QUERY?7:0;return TRUE;
}
DWORD WINAPI __wrap_WaitForSingleObject(HANDLE h,DWORD ms){
 (void)h;(void)ms;return last_request==SPI_BACKLIGHT_SET && set_error==ERROR_TIMEOUT && !cancelled?WAIT_TIMEOUT:WAIT_OBJECT_0;
}
BOOL WINAPI __wrap_CancelIoEx(HANDLE h,LPOVERLAPPED ov){(void)h;(void)ov;cancelled=1;return TRUE;}
static int run_case(int percent,DWORD qe,DWORD se,int async,int expected_ready,int expected_popup){
 query_error=qe;set_error=se;pending=async;cancelled=0;query_calls=set_calls=0;uncertain=0;
 perform_action(percent);
 if(query_calls!=1 || set_calls!=(qe?0:1) || ready!=expected_ready || (!!error_text[0])!=expected_popup)return 0;
 return 1;
}
int main(void){
 for(int i=0;i<5;i++){
  if(!run_case(levels[i],0,0,0,1,0))return 10+i;
  if(!run_case(levels[i],0,ERROR_GEN_FAILURE,0,1,0))return 20+i;
  if(!run_case(levels[i],0,ERROR_GEN_FAILURE,1,1,0))return 30+i;
 }
 if(!run_case(50,ERROR_GEN_FAILURE,0,0,0,1))return 40;
 if(!run_case(50,0,ERROR_ACCESS_DENIED,0,1,1))return 41;
 if(!run_case(100,0,ERROR_DEVICE_NOT_CONNECTED,0,1,1))return 42;
 if(!run_case(100,0,ERROR_TIMEOUT,1,0,1) || !uncertain)return 43;
 puts("19 regression cases passed: only setter error31 silent; query31/access/disconnection/timeout visible; no repeated writes.");
 return 0;
}

__typeof__(&__wrap_CreateFileW) __wrap___imp_CreateFileW = __wrap_CreateFileW;
__typeof__(&__wrap_DeviceIoControl) __wrap___imp_DeviceIoControl = __wrap_DeviceIoControl;
__typeof__(&__wrap_GetOverlappedResult) __wrap___imp_GetOverlappedResult = __wrap_GetOverlappedResult;
__typeof__(&__wrap_WaitForSingleObject) __wrap___imp_WaitForSingleObject = __wrap_WaitForSingleObject;
__typeof__(&__wrap_CancelIoEx) __wrap___imp_CancelIoEx = __wrap_CancelIoEx;
