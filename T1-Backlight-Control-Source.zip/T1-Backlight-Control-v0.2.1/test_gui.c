#define UNICODE
#define _UNICODE
#include <windows.h>
#include <wchar.h>
#include <stdio.h>
static int children;
static BOOL CALLBACK count_child(HWND h,LPARAM p){(void)h;(void)p;children++;return TRUE;}
int main(void){
 HWND w=NULL,dialog=NULL;
 for(int i=0;i<100 && !w;i++){w=FindWindowW(L"T1BacklightControl",NULL);Sleep(100);}
 if(!w)return 1;
 for(int i=0;i<100 && !dialog;i++){dialog=FindWindowW(L"#32770",L"Подсветка");Sleep(100);}
 if(!dialog)return 2;
 SendMessageW(dialog,WM_COMMAND,IDOK,0);Sleep(100);
 EnumChildWindows(w,count_child,0);if(children!=5)return 3;
 const wchar_t *labels[5]={L"25%",L"50%",L"75%",L"100%",L"Выкл"};
 for(int i=0;i<5;i++){
  HWND b=GetDlgItem(w,101+i);wchar_t label[32]={0};
  if(!b || IsWindowEnabled(b))return 4;
  SendMessageW(b,WM_GETTEXT,32,(LPARAM)label);if(wcscmp(label,labels[i]))return 5;
 }
 SendMessageW(w,WM_COMMAND,101,0);Sleep(100);
 if(FindWindowW(L"#32770",L"Подсветка"))return 6;
 puts("GUI: exactly five correctly labelled buttons; unavailable-driver gate passed.");
 return 0;
}
